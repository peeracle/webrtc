Appurify Developer Python Client
--------------------------------

Environment variables:
    
    - APPURIFY_API_PROTO
    - APPURIFY_API_HOST
    - APPURIFY_API_PORT
    
    - APPURIFY_API_TIMEOUT
    - APPURIFY_API_POLL_DELAY
    
    - APPURIFY_API_RETRY_ON_FAILURE
    - APPURIFY_API_MAX_RETRY
    - APPURIFY_API_RETRY_DELAY

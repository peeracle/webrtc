def print_multi_test_responses(test_response):
    print 'im here'
    response_pass = True
    for result in test_response:
        log("Device Type %s result:" % result['device_type'])
        self.print_single_test_response(result["results"])
        log("\n")
    return response_pass

